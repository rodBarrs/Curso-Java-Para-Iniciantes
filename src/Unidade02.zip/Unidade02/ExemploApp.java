package Unidade02;

import javax.swing.*;

public class ExemploApp {

    public static void main(String[] args) {

        /*
        System.out.println("Mensagem 1");
        System.out.println("Mensagem 2");
        System.out.println("Mensagem 3");
        System.out.println("Mensagem 4");
        */

        JOptionPane.showMessageDialog(null,"Mensagem 1");
        JOptionPane.showMessageDialog(null,"Mensagem 2");
        JOptionPane.showMessageDialog(null,"Mensagem 3");
        JOptionPane.showMessageDialog(null,"Mensagem 4");

    }

}
