package Unidade02;

public class ExemploVariaveis {

    public static void main(String[] args) {

        int anoNascimento = 1975;

        int x, y;
        float z = 3.144f;
        double w = 3.1415;
        boolean verdade = true;
        char c, d;
        c = 'A';
    }
}
