package Unidade04.rh;

public interface Contribuinte {

    void pagaIR();
    String getCPF();



}
