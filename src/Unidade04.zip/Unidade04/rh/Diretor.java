package Unidade04.rh;

public class Diretor extends Funcionario {

    String departamento;

    @Override
    public void getBonificacao() {

    }
}
