package Unidade04.rh;

public interface Cidadao {

    void vota();

    String getRG();



}
