package Unidade04.rh;

public class Administrativo extends Funcionario{
    @Override
    public void getBonificacao() {

    }
}
