package Unidade04.rh;

public interface Autenticavel {

    boolean autentica(String senha);

}
