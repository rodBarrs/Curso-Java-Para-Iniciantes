package Unidade01;

public class Propriedades {
    public static void main(String[] args) {
        String so = System.getProperty("os.name");
        System.out.println(so);
    }
}
