package Unidade03.sisalucar;

public class Veiculo {

    protected float autonomia;

    public void acelera(){}

    public void freia(){}

    public float getVelocidade() {return 0;}

    public int getPassageiros(){return 0;}



}
